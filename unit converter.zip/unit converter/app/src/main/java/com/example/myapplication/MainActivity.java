package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton imageButton,imageButton2,imageButton3;
    TextView textView,textView2,textView3;
    EditText editTextNumber;
    Spinner spinner;
    float number,value1,value2,value3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        imageButton=findViewById(R.id.imageButton);
        imageButton2=findViewById(R.id.imageButton2);
        imageButton3=findViewById(R.id.imageButton3);
        textView=findViewById(R.id.textView);
        textView2=findViewById(R.id.textView2);
        textView3=findViewById(R.id.textView3);
        editTextNumber=findViewById(R.id.editTextNumber);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedItem().toString().equals("Metre"))
                {
                    number=Float.parseFloat(editTextNumber.getText().toString());
                    value1=100*number;
                    value2=(float)((3.280084)*number);
                    value3=(float)((39.3701)*number);

                    textView.setText((String.format("%.2f",value1)+"centimetre"));
                    textView2.setText(String.format("%.2f",value2)+"foot");
                    textView3.setText(String.format("%.2f",value3)+"Inch");

                }
                else
                {
                    textView.setText("");
                    textView2.setText("");
                    textView3.setText("");

                    Toast.makeText( MainActivity.this ,  "Incorrect Button",Toast.LENGTH_LONG).show();
                }
            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(spinner.getSelectedItem().toString().equals("Celsius"))
                {
                    number=Float.parseFloat(editTextNumber.getText().toString());
                    value1=(float)(9*number)/5+32;
                    value2=(float)(number+273.151);

                    textView.setText((String.format("%.2f",value1)+"Fahrenheit"));
                    textView2.setText(String.format("%.2f",value2)+"Kelvin");
                    textView3.setText("");

                }
                else
                {
                    textView.setText("");
                    textView2.setText("");
                    textView3.setText("");

                    Toast.makeText( MainActivity.this ,  "Incorrect Button",Toast.LENGTH_LONG).show();
                }
            }
        });
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (spinner.getSelectedItem().toString().equals("Kilogram"))
                {
                    number = Float.parseFloat(editTextNumber.getText().toString());
                    value1 = 1000*number;
                    value2 = (float) ((35.274)*number);
                    value3 = (float) ((2.205)*number);

                    textView.setText( (String.format("%.2f", value1)) + "Grams");
                    textView2.setText( (String.format("%.2f", value2)) + "Ounces");
                    textView3.setText( (String.format("%.2f", value3)) + "Pound");
                }

                else
                {
                    textView.setText("");
                    textView2.setText("");
                    textView3.setText("");

                    Toast.makeText( MainActivity.this ,  "Incorrect Button",Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}